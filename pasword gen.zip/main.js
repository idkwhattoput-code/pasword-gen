const lengthInput = document.getElementById('length');
const uppercaseInput = document.getElementById('uppercase');
const lowercaseInput = document.getElementById('lowercase');
const numbersInput = document.getElementById('numbers');
const symbolsInput = document.getElementById('symbols');
const generateBtn = document.getElementById('generateBtn');
const passwordInput = document.getElementById('password');
const copyBtn = document.getElementById('copyBtn');

const uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';
const numberChars = '0123456789';
const symbolChars = '!@#$%^&*()_+[]{}<>?,.';

generateBtn.addEventListener('click', () => {
    const length = parseInt(lengthInput.value);
    const includeUppercase = uppercaseInput.checked;
    const includeLowercase = lowercaseInput.checked;
    const includeNumbers = numbersInput.checked;
    const includeSymbols = symbolsInput.checked;

    const generatedPassword = generatePassword(length, includeUppercase, includeLowercase, includeNumbers, includeSymbols);
    passwordInput.value = generatedPassword;
});

function generatePassword(length, uppercase, lowercase, numbers, symbols) {
    let charPool = '';
    let password = '';

    if (uppercase) charPool += uppercaseChars;
    if (lowercase) charPool += lowercaseChars;
    if (numbers) charPool += numberChars;
    if (symbols) charPool += symbolChars;

    if (charPool.length === 0) {
        alert('Please select at least one character type');
        return '';
    }

    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charPool.length);
        password += charPool[randomIndex];
    }

    return password;
}

copyBtn.addEventListener('click', () => {
    passwordInput.select();
    document.execCommand('copy');
    alert('Password copied to clipboard!');
});
